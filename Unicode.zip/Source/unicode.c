/*****************************************************************
 *       NSIS plugin for Unicode files conversion v1.0           *
 *                                                               *
 * 2005 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *****************************************************************/

#include <windows.h>
#include "exdll.h"

int __UnicodeType(char *chInFile);

void __declspec(dllexport) UnicodeType(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop,
                                      extra_parameters *extra)
{
	EXDLL_INIT();

	{
		char chInFile[1024];
		char error[2]="0";

		popstring(chInFile);
		if (chInFile[0] == 0)
		{
			char error[2]="1";
			pushstring(error);
			return;
		}

		__UnicodeType(chInFile);
	}
}

void __declspec(dllexport) FileUnicode2Ansi(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop,
                                      extra_parameters *extra)
{
	EXDLL_INIT();

	{
		HANDLE hFileRead=0;
		HANDLE hFileWrite=0;
		char chInFile[1024];
		char chOutFile[1024];
		char chUnicodeType[1024];
		char error[2]="0";
		int nUnicodeType=0;
		int nMultiByteLen=0;
		DWORD dwNumberOfBytesRead=0;
		DWORD dwNumberOfBytesWritten=0;
		DWORD dwBytesToRead=0;
		void *pReadBuffer=NULL;
		char *pBufferMultiByte=NULL;
		WCHAR *pBufferWideCharLEw=NULL;
		char *pBufferWideCharLEa=NULL;

//Get parameters
		popstring(chInFile);
		if (chInFile[0] == 0)
		{
			error[0]='1';
			goto exit;
		}
		popstring(chOutFile);
		if (chOutFile[0] == 0)
		{
			error[0]='1';
			goto exit;
		}
		popstring(chUnicodeType);
		if (chUnicodeType[0] == 0)
		{
			error[0]='1';
			goto exit;
		}
		if ((lstrcmpi(chUnicodeType, "AUTO") != 0) &&
			(lstrcmpi(chUnicodeType, "UTF-8") != 0) &&
			(lstrcmpi(chUnicodeType, "UTF-16LE") != 0) &&
			(lstrcmpi(chUnicodeType, "UTF-16BE") != 0))
		{
			error[0]='2';
			goto exit;
		}

//Get unicode file type
		if (lstrcmpi(chUnicodeType, "AUTO") == 0)
		{
			nUnicodeType=__UnicodeType(chInFile);
			if (nUnicodeType == -1)
				return;
			else if (nUnicodeType == 0)
			{
				popstring(NULL);
				error[0]='4';
				goto exit;
			}
			else if ((nUnicodeType == 44) || (nUnicodeType == 46))
			{
				popstring(NULL);
				error[0]='5';
				goto exit;
			}
		}

//ReadFile
		hFileRead=CreateFile(chInFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
		if (hFileRead == INVALID_HANDLE_VALUE)
		{
			error[0]='6';
			goto exit;
		}

		dwBytesToRead=GetFileSize(hFileRead, NULL);
		pReadBuffer=GlobalAlloc(GPTR, dwBytesToRead+1);
		ReadFile(hFileRead, pReadBuffer, dwBytesToRead, &dwNumberOfBytesRead, NULL);
		CloseHandle(hFileRead);

//ConvertFile
		if ((nUnicodeType == 13) || (lstrcmpi(chUnicodeType, "UTF-8") == 0))
		{
			//UTF-8 -> UTF-16LE
			pBufferWideCharLEw=(WCHAR*)GlobalAlloc(GPTR, dwBytesToRead*2);
			MultiByteToWideChar(CP_UTF8, 0, pReadBuffer, -1, pBufferWideCharLEw, dwBytesToRead);

			//UTF-16LE -> ANSI
			pBufferMultiByte=(char*)GlobalAlloc(GPTR, dwBytesToRead);
			nMultiByteLen=WideCharToMultiByte(CP_ACP, 0, pBufferWideCharLEw, -1, pBufferMultiByte, dwBytesToRead, 0, 0);
			--nMultiByteLen;
			if (lstrcmpi(chUnicodeType, "UTF-8") != 0)
			{
				++pBufferMultiByte;
				--nMultiByteLen;
			}
		}
		else if ((nUnicodeType == 22) || (lstrcmpi(chUnicodeType, "UTF-16LE") == 0))
		{
			//UTF-16LE -> ANSI
			pBufferMultiByte=(char*)GlobalAlloc(GPTR, dwBytesToRead/2);
			nMultiByteLen=WideCharToMultiByte(CP_ACP, 0, pReadBuffer, dwBytesToRead/2, pBufferMultiByte, dwBytesToRead, 0, 0);
			if (lstrcmpi(chUnicodeType, "UTF-16LE") != 0)
			{
				++pBufferMultiByte;
				--nMultiByteLen;
			}
		}
		else if ((nUnicodeType == 23) || (lstrcmpi(chUnicodeType, "UTF-16BE") == 0))
		{
			DWORD dwCount=0;
			DWORD dwCount2=0;
			char *pBufferWideCharLEa2=NULL;

			//UTF-16BE -> UTF-16LE
			pBufferWideCharLEa=(char*)GlobalAlloc(GPTR, dwBytesToRead);
			pBufferWideCharLEa2=(char*)pReadBuffer;

			for (dwCount=0, dwCount2=1; dwCount != dwBytesToRead; dwCount+=2, dwCount2+=2)
			{
				pBufferWideCharLEa[dwCount]=pBufferWideCharLEa2[dwCount2];
				pBufferWideCharLEa[dwCount2]=pBufferWideCharLEa2[dwCount];
			}
			pBufferWideCharLEw=(WCHAR*)pBufferWideCharLEa;

			//UTF-16LE -> ANSI
			pBufferMultiByte=(char*)GlobalAlloc(GPTR, dwBytesToRead/2);
			nMultiByteLen=WideCharToMultiByte(CP_ACP, 0, pBufferWideCharLEw, dwBytesToRead/2, pBufferMultiByte, dwBytesToRead, 0, 0);
			if (lstrcmpi(chUnicodeType, "UTF-16BE") != 0)
			{
				++pBufferMultiByte;
				--nMultiByteLen;
			}
		}

//WriteFile
		hFileWrite=CreateFile(chOutFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		if (hFileWrite == INVALID_HANDLE_VALUE)
		{
			error[0]='7';
			goto exit;
		}

		WriteFile(hFileWrite, pBufferMultiByte, nMultiByteLen, &dwNumberOfBytesWritten, NULL);
		CloseHandle(hFileWrite);
 
//Exit
exit:
		if (pReadBuffer)
			GlobalFree(pReadBuffer);
		if (pBufferMultiByte)
			GlobalFree(pBufferMultiByte);
		if (pBufferWideCharLEw)
			GlobalFree(pBufferWideCharLEw);
		pushstring(error);
	}
}

void __declspec(dllexport) FileAnsi2Unicode(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop,
                                      extra_parameters *extra)
{
	EXDLL_INIT();

	{
		HANDLE hFileRead=0;
		HANDLE hFileWrite=0;
		char chInFile[1024];
		char chOutFile[1024];
		char chUnicodeType[1024];
		char error[2]="0";
		int nUnicodeType=0;
		int nMultiByteLen=0;
		int nBufferLen=0;
		DWORD dwNumberOfBytesRead=0;
		DWORD dwNumberOfBytesWritten=0;
		DWORD dwBytesToRead=0;
		DWORD dwWideCharByteLen=0;
		void *pReadBuffer=NULL;
		char *pBufferMultiByte=NULL;
		WCHAR *pBufferWideCharLEw=NULL;
		void *pBufferWrite=NULL;
		char *pBufferWideCharBEa=NULL;

//Get parameters
		popstring(chInFile);
		if (chInFile[0] == 0)
		{
			error[0]='1';
			goto exit;
		}
		popstring(chOutFile);
		if (chOutFile[0] == 0)
		{
			error[0]='1';
			goto exit;
		}
		popstring(chUnicodeType);
		if (chUnicodeType[0] == 0)
		{
			error[0]='1';
			goto exit;
		}

//Get unicode file type
		nUnicodeType=__UnicodeType(chInFile);
		if (nUnicodeType == -1)
			return;
		else if (nUnicodeType != 0)
		{
			popstring(NULL);
			error[0]='3';
			goto exit;
		}

//ReadFile
		hFileRead=CreateFile(chInFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
		if (hFileRead == INVALID_HANDLE_VALUE)
		{
			error[0]='6';
			goto exit;
		}

		dwBytesToRead=GetFileSize(hFileRead, NULL);
		pReadBuffer=GlobalAlloc(GPTR, dwBytesToRead+1);
		ReadFile(hFileRead, pReadBuffer, dwBytesToRead, &dwNumberOfBytesRead, NULL);
		CloseHandle(hFileRead);

//ConvertFile
		if (lstrcmpi(chUnicodeType, "UTF-8") == 0)
		{
			//ANSI -> UTF-16LE
			pBufferWideCharLEw=(WCHAR*)GlobalAlloc(GPTR, dwBytesToRead*2);
			MultiByteToWideChar(CP_ACP, 0, pReadBuffer, dwBytesToRead, pBufferWideCharLEw, dwBytesToRead);

			//Add BOM
			pBufferMultiByte=(char*)GlobalAlloc(GPTR, dwBytesToRead*2);
			pBufferMultiByte[0]=(char)0xEF;
			pBufferMultiByte[1]=(char)0xBB;
			pBufferMultiByte[2]=(char)0xBF;
			pBufferMultiByte+=3;

			//UTF-16LE -> UTF-8
			nBufferLen=WideCharToMultiByte(CP_UTF8, 0, pBufferWideCharLEw, dwBytesToRead, pBufferMultiByte, dwBytesToRead*2, 0, 0);
			pBufferWrite=pBufferMultiByte - 3;
			nBufferLen+=3;
		}
		else if (lstrcmpi(chUnicodeType, "UTF-16LE") == 0)
		{
			//Add BOM
			dwWideCharByteLen=dwBytesToRead*2 + 2;
			pBufferWideCharLEw=(WCHAR*)GlobalAlloc(GPTR, dwWideCharByteLen);
			pBufferWideCharLEw[0]=0xFEFF;
			++pBufferWideCharLEw;

			//ANSI -> UTF-16LE
			MultiByteToWideChar(CP_ACP, 0, pReadBuffer, dwBytesToRead, pBufferWideCharLEw, dwBytesToRead);
			pBufferWrite=--pBufferWideCharLEw;
			nBufferLen=dwWideCharByteLen;
		}
		else if (lstrcmpi(chUnicodeType, "UTF-16BE") == 0)
		{
			DWORD dwCount=0;
			DWORD dwCount2=0;
			char *pBufferWideCharBEa2=NULL;

			//Add BOM
			dwWideCharByteLen=dwBytesToRead*2 + 2;
			pBufferWideCharLEw=(WCHAR*)GlobalAlloc(GPTR, dwWideCharByteLen);
			pBufferWideCharLEw[0]=0xFEFF;
			++pBufferWideCharLEw;

			//ANSI -> UTF-16LE
			MultiByteToWideChar(CP_ACP, 0, pReadBuffer, dwBytesToRead, pBufferWideCharLEw, dwBytesToRead);
			--pBufferWideCharLEw;

			//UTF-16LE -> UTF-16BE
			pBufferWideCharBEa=(char*)GlobalAlloc(GPTR, dwWideCharByteLen + 2);
			pBufferWideCharBEa2=(char*)pBufferWideCharLEw;

			for (dwCount=0, dwCount2=1; dwCount != dwWideCharByteLen; dwCount+=2, dwCount2+=2)
			{
				pBufferWideCharBEa[dwCount]=pBufferWideCharBEa2[dwCount2];
				pBufferWideCharBEa[dwCount2]=pBufferWideCharBEa2[dwCount];
			}
			nBufferLen=dwWideCharByteLen;
			pBufferWrite=pBufferWideCharBEa;
		}
		else if ((lstrcmpi(chUnicodeType, "UTF-32LE") == 0) || (lstrcmpi(chUnicodeType, "UTF-32BE") == 0))
		{
			error[0]='5';
			goto exit;
		}
		else
		{
			error[0]='2';
			goto exit;
		}

//WriteFile
		hFileWrite=CreateFile(chOutFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		if (hFileWrite == INVALID_HANDLE_VALUE)
		{
			error[0]='7';
			goto exit;
		}
		WriteFile(hFileWrite, pBufferWrite, nBufferLen, &dwNumberOfBytesWritten, NULL);
		CloseHandle(hFileWrite);
 
//Exit
exit:
		if (pReadBuffer)
			GlobalFree(pReadBuffer);
		if (pBufferMultiByte)
			GlobalFree(pBufferMultiByte);
		if (pBufferWideCharLEw)
			GlobalFree(pBufferWideCharLEw);
		if (pBufferWideCharBEa)
			GlobalFree(pBufferWideCharBEa);
		pushstring(error);
	}
}

int __UnicodeType(char *chInFile)
{
	HANDLE hFileRead=0;
	BYTE bom[32];
	DWORD dwNumberOfBytesRead=0;

	hFileRead=CreateFile(chInFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFileRead == INVALID_HANDLE_VALUE)
	{
		pushstring("6");
		return -1;
	}
	ReadFile(hFileRead, &bom, 4, &dwNumberOfBytesRead, NULL);
	CloseHandle(hFileRead);

	if (bom[0] == 0xEF && bom[1] == 0xBB && bom[2] == 0xBF)
	{
		pushstring("UTF-8");                    //  Variable Width (Web)
		return 13;
	}
		else if (bom[0] == 0xFF && bom[1] == 0xFE && bom[2] == 0 && bom[3] == 0)
		{
			pushstring("UTF-32LE|UCS-4LE");   // 32-bit Little Endian
			return 44;
		}
		else if (bom[0] == 0 && bom[1] == 0 && bom[2] == 0xFE&& bom[3] == 0xFF)
		{
			pushstring("UTF-32BE|UCS-4BE");   // 32-bit Big Endian
			return 46;
		}
		else if (bom[0] == 0xFF && bom[1] == 0xFE)
		{
			pushstring("UTF-16LE|UCS-2LE");   // Little Endian (Default for Windows)
			return 22;
		}
		else if (bom[0] == 0xFE && bom[1] == 0xFF)
		{
			pushstring("UTF-16BE|UCS-2BE");   // Big Endian (Default for Linux)
			return 23;
		}
		else
		{
			pushstring("NONE");              // None Unicode
			return 0;
		}
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
